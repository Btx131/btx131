<?php

namespace App\Controller;

use App\Entity\Question;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;
use Doctrine\Persistence\ManagerRegistry;

class QuestionController extends AbstractController
{
    #[Route('/questions', name: 'app_question')]
    public function index(): Response
    {
        return $this->render('questions/index.html.twig', [
            'controller_name' => 'QuestionController',
        ]);
    }
    #[Route('/questions/save')]
    public function save(ManagerRegistry $doctrine): Response // Dodano parametr $doctrine [[5]]
    {
        $entityManager = $doctrine->getManager(); // Użyto $doctrine zamiast $this->getDoctrine()

        $question = new Question();
        $question->setContent('Jakie zwierzę potrafi spać nawet 22 godziny na dobę?');
        $question->setCorrectAnswer('a');

        $entityManager->persist($question);
        $entityManager->flush();

        return new Response('Zapisano pytanie z ID: ' . $question->getId()); // Poprawiono interpunkcję
    }
}
